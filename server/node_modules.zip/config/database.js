import mysql from "mysql2";

const userName = 'pentique_admin'
const password = 'X:5BVLamzWD9Qd7'

const db = mysql.createConnection({
     host:"localhost",
     user: userName,
     password: password,
     database: "pentique_pentiquedb"
 });

export default db;